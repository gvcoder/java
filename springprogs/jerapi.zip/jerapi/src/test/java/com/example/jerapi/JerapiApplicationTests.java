package com.example.jerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JerapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
