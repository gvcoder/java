package com.example.jerapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JerapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JerapiApplication.class, args);
	}

}
